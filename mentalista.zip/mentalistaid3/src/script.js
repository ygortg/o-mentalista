function Chutar() {
  var resposta = document.getElementById("resultado");
  var chute = parseInt(document.getElementById("valor").value);
  if (chute == numeroSecreto) {
    resposta.innerHTML = "Acertou";
  } else if (chute > 10 || chute < 0) {
    resposta.innerHTML = "Digite um numero de 0 a 10";
  } else if (chute != numeroSecreto) {
    resposta.innerHTML =
      "Errou, seu numero esta entre " +
      (numeroSecreto - 3) +
      " e " +
      (numeroSecreto + 3);
  }
}
var numeroSecreto = parseInt(Math.random() * 11);

function Reset() {
  numeroSecreto = parseInt(Math.random() * 11);
}
